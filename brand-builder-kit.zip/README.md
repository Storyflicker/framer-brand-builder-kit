# Brand Builder Kit

Brand Builder Kit is a Framer plugin designed to help creators and startups instantly generate complete brand kits from a logo and name. 

## ✨ Features

- Upload your logo and auto-generate brand colors
- Choose font pairings for heading and body text
- Preview logo variations and favicons
- Export a complete brand kit directly into your Framer project

## 🚀 Getting Started

1. Install the plugin in Framer Web
2. Upload your brand logo
3. Customize your brand name, colors, and typography
4. Click "Generate Brand Kit" to auto-insert into your project

## 🧠 Tech Stack

- React + TypeScript
- Framer Plugin API
- CSS Modules

## 📦 Build & Deploy

```bash
npm install
npm run dev
```

## 🔗 License

MIT
