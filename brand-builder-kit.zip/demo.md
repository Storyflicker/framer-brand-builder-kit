# Demo Walkthrough

## How to Use Brand Builder Kit

1. Open your Framer Web project.
2. Click on 'Insert' → search 'Brand Builder Kit'
3. Drop the plugin component into your canvas.
4. Upload your logo file (SVG or PNG).
5. Select your primary, secondary, and accent colors.
6. Choose a typography pairing from suggested fonts or enter custom ones.
7. Preview everything in real-time.
8. Hit 'Generate Brand Kit' – and it's automatically inserted into your Framer canvas!

## Coming Soon

- Export to Notion Brand Book
- AI-powered slogan generator
- One-click favicon export
